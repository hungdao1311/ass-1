/*
 * =========================================================================================
 * Name        : listLib.h
 * Author      : Duc Dung Nguyen
 * Email       : nddung@hcmut.edu.vn
 * Copyright   : Faculty of Computer Science and Engineering - Bach Khoa University
 * Description : library for Assignment 1 - Data structures and Algorithms - Fall 2017
 * =========================================================================================
 */

#ifndef A01_LISTLIB_H
#define A01_LISTLIB_H

#include <string>
#include <stdio.h>
#include <string.h>
#include <iostream>

using namespace std;

class DSAException {
    int     _error;
    string  _text;
public:

    DSAException() : _error(0), _text("Success") {}
    DSAException(int err) : _error(err), _text("Unknown Error") {}
    DSAException(int err, const char* text) : _error(err), _text(text) {}

    int getError() { return _error; }
    string& getErrorText() { return _text; }
};

template <class T>
struct L1Item {
    T data;
    L1Item<T> *pNext;
    L1Item<T> *pChild;
    L1Item<T> *pTailchild;
    L1Item() : pNext(NULL) {}
    L1Item(T &a) : data(a), pNext(NULL), pChild(NULL), pTailchild(NULL) {}
    int push_child(T&a);
};

template <class T>
class L1List {
    L1Item<T>   *_pHead;// The head pointer of linked list
    L1Item<T>   *_pTail;   // The tail pointer of linked list
    size_t      _size;// number of elements in this list
public:
    L1List() : _pHead(NULL), _size(0) {}
    ~L1List();

    void    clean();
    bool    isEmpty() {
        return _pHead == NULL;
    }
    size_t  getSize() {
        return _size;
    }

    L1Item<T>* getHead(){
        return _pHead;
    };

    L1Item<T>* getTail(){
        return _pTail;
    }

    T&      at(int i);
    T&      operator[](int i);

    bool    find(T& a, int& idx);
    int     insert(int i, T& a);
    int     remove(int i);

    int     push_back(T& a);
    int     insertHead(T& a);

    int     removeHead();
    int     removeLast();

    void    reverse();

    void    traverse(void (*op)(T&)) {
        L1Item<T>   *p = _pHead;
        while (p) {
            op(p->data);
            p = p->pNext;
        }
    }
    void    traverse(void (*op)(T&, void*), void* pParam) {
        L1Item<T>   *p = _pHead;
        while (p) {
            op(p->data, pParam);
            p = p->pNext;
        }
    }
};



/// Insert item to the end of the list
/// Return 0 if success
template <class T>
int L1List<T>::push_back(T &a) {

    if (_pHead == NULL) {
        _pHead = new L1Item<T>(a);
        _pTail = _pHead;

    }
    else {
        _pTail->pNext = new L1Item<T>(a);
        _pTail = _pTail->pNext;
    }
    _size++;
    return 0;
}

template<class T>
int L1Item<T>::push_child(T &a) {
    if(pTailchild == NULL) pTailchild = this;
    pTailchild->pChild = new L1Item<T>(a);
    pTailchild = pTailchild->pChild;
    return 0;
}

/// Insert item to the front of the list
/// Return 0 if success
template <class T>
int L1List<T>::insertHead(T &a) {
    L1Item<T>   *p = new L1Item<T>(a);
    p->pNext = _pHead;
    _pHead = p;
    _size++;
    return 0;
}

/// Remove the first item of the list
/// Return 0 if success
template <class T>
int L1List<T>::removeHead() {
    if(_pHead) {
        L1Item<T>* p = _pHead;
        _pHead = p->pNext;
        delete p;
        _size--;
        return 0;
    }
    return -1;
}

/// Remove the last item of the list
/// Return 0 if success
template <class T>
int L1List<T>::removeLast() {
    if(_pHead) {
        if(_pHead->pNext) {
            L1Item<T>* prev = _pHead;
            L1Item<T>* pcur = prev->pNext;
            while(pcur->pNext) {
                prev = pcur;
                pcur = pcur->pNext;
            }
            delete pcur;
            prev->pNext = NULL;
        }
        else {
            delete _pHead;
            _pHead = NULL;
        }
        _size--;
        return 0;
    }
    return -1;
}

//Get by index
template <class T>
T& L1List<T>::operator[](int i) {
    int j = 0;
    L1Item<T>* temp = _pHead;
    while(i != j){
        temp = temp->pNext;
        j++;
    }
    return temp->data;
}

template <class T>
L1List<T>::~L1List() {
    L1Item<T>* temp = _pHead;
    while(temp != NULL){
        temp=temp->pNext;
        delete temp;
    }
}



#endif //A01_LISTLIB_H
